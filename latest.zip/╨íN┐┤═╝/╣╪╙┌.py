import pygame
import sys
import os
import platform

# 初始化pygame
pygame.init()

# 设置中文字体
def get_system_font(size=16):
    """获取系统字体"""
    system = platform.system()
    if system == "Windows":
        fonts = ["SimHei", "Microsoft YaHei", "SimSun"]
    elif system == "Darwin":
        fonts = ["PingFang SC", "Heiti SC", "STHeiti"]
    else:
        fonts = ["Noto Sans CJK SC", "WenQuanYi Micro Hei"]
    
    for font_name in fonts:
        try:
            font = pygame.font.SysFont(font_name, size)
            # 测试字体是否能渲染中文
            test_surface = font.render("测试", True, (0, 0, 0))
            if test_surface.get_width() > 0:
                return font
        except:
            continue
    
    # 如果所有系统字体都失败，使用默认字体
    return pygame.font.Font(None, size)

class AboutWindow:
    def __init__(self, width=400, height=500):
        """初始化关于窗口"""
        try:
            self.width = max(400, int(width))  # 确保最小宽度
            self.height = max(500, int(height))  # 确保最小高度
        except (ValueError, TypeError):
            self.width = 400
            self.height = 500
            
        # 创建窗口
        try:
            self.screen = pygame.display.set_mode((self.width, self.height))
            pygame.display.set_caption("关于 - 小N看图")
        except Exception as e:
            print(f"创建窗口失败: {e}")
            # 使用默认大小重试
            self.width = 400
            self.height = 500
            self.screen = pygame.display.set_mode((self.width, self.height))
            pygame.display.set_caption("关于 - 小N看图")
        
        # 颜色定义
        self.bg_color = (245, 245, 245)
        self.title_color = (50, 50, 50)
        self.text_color = (80, 80, 80)
        self.accent_color = (100, 149, 237)
        self.button_color = (100, 149, 237)
        self.button_hover_color = (135, 206, 250)
        
        # 字体 - 使用更兼容的字体设置
        try:
            self.title_font = get_system_font(24)
            self.subtitle_font = get_system_font(14)
            self.text_font = get_system_font(12)
            self.small_font = get_system_font(10)
        except Exception as e:
            print(f"字体加载失败: {e}")
            self.title_font = pygame.font.Font(None, 24)
            self.subtitle_font = pygame.font.Font(None, 14)
            self.text_font = pygame.font.Font(None, 12)
            self.small_font = pygame.font.Font(None, 10)
        
        # 关闭按钮
        button_width = 120
        button_height = 35
        button_x = (self.width - button_width) // 2
        button_y = self.height - 80
        
        # 确保按钮在窗口内
        if button_y < 200:  # 防止按钮太靠上
            button_y = self.height - 100
            
        self.close_button_rect = pygame.Rect(button_x, button_y, button_width, button_height)
        
        # 图标
        self.load_icon()
        
    def load_icon(self):
        """加载图标"""
        self.icon = None
        try:
            icon_path = os.path.join("images", "图标.png")
            if os.path.exists(icon_path):
                icon_img = pygame.image.load(icon_path)
                # 根据窗口大小调整图标大小
                icon_size = min(80, self.width // 5)
                self.icon = pygame.transform.scale(icon_img, (icon_size, icon_size))
        except Exception as e:
            print(f"图标加载失败: {e}")
            pass
    
    def draw(self):
        """绘制界面"""
        try:
            self.screen.fill(self.bg_color)
            
            # 绘制标题背景
            title_height = min(120, self.height // 4)
            title_rect = pygame.Rect(0, 0, self.width, title_height)
            pygame.draw.rect(self.screen, self.accent_color, title_rect)
            
            # 绘制图标
            if self.icon:
                icon_size = self.icon.get_width()
                icon_x = (self.width - icon_size) // 2
                icon_y = 20 if self.height > 400 else 10
                self.screen.blit(self.icon, (icon_x, icon_y))
            
            # 绘制标题
            title_text = self.title_font.render("小N看图1.2", True, (255, 255, 255))
            title_x = (self.width - title_text.get_width()) // 2
            title_y = title_height - 30 if self.height > 400 else title_height - 20
            self.screen.blit(title_text, (title_x, title_y))
            
            # 绘制功能列表
            content_start = title_height + 20
            features = [
                "功能特性：",
                "• 图片浏览 - 支持多种图片格式",
                "• 格式转换 - 一键转换图片格式",
                "• 图片裁剪 - 精确裁剪任意区域",
                "• 图片旋转 - 90度旋转功能",
                "• 拖拽打开 - 支持拖拽图片打开",
                "• 快捷键支持 - Ctrl+O打开, Ctrl+S保存",
                "致谢：",
                "SYSTEM-SHITTIMSCHEST-MF. 010"
                "SYSTEM-KUBUNTU-LH（石山代码批发） 012",
                "Warp工作室（室长）000",
                "Trae CN"
            ]
            
            line_height = 25
            for i, feature in enumerate(features):
                if content_start + i * line_height > self.height - 150:
                    break  # 防止内容超出窗口
                    
                if i == 0:  # 标题
                    color = self.title_color
                    font = self.subtitle_font
                else:
                    color = self.text_color
                    font = self.text_font
                
                text_surface = font.render(feature, True, color)
                self.screen.blit(text_surface, (30, content_start + i * line_height))
            
            # 绘制描述
            desc_start = content_start + len(features) * line_height + 10
            desc_text = [
                "小N看图是一款功能强大的图片处理工具，",
                "支持多种图片格式的浏览、转换、裁剪和旋转等操作。",
                "简洁的界面设计和丰富的快捷键支持，",
                "让您的图片处理体验更加高效便捷。"
            ]
            
            desc_line_height = 20
            for i, desc in enumerate(desc_text):
                if desc_start + i * desc_line_height > self.height - 150:
                    break
                    
                text_surface = self.text_font.render(desc, True, self.text_color)
                self.screen.blit(text_surface, (30, desc_start + i * desc_line_height))
            
            # 绘制版权信息
            copyright_text = "© 2025 Warp工作室  版本1.2"

            try:
                copyright_surface = self.small_font.render(copyright_text, True, (150, 150, 150))
                copyright_x = (self.width - copyright_surface.get_width()) // 2
                copyright_y = self.height - 120
                self.screen.blit(copyright_surface, (copyright_x, copyright_y))
            except:
                pass
            
            # 绘制关闭按钮
            mouse_pos = pygame.mouse.get_pos()
            is_hover = self.close_button_rect.collidepoint(mouse_pos)
            button_color = self.button_hover_color if is_hover else self.button_color
            
            pygame.draw.rect(self.screen, button_color, self.close_button_rect, border_radius=18)
            pygame.draw.rect(self.screen, (255, 255, 255), self.close_button_rect, 2, border_radius=18)
            
            close_text = self.text_font.render("关闭", True, (255, 255, 255))
            close_x = self.close_button_rect.x + (self.close_button_rect.width - close_text.get_width()) // 2
            close_y = self.close_button_rect.y + (self.close_button_rect.height - close_text.get_height()) // 2
            self.screen.blit(close_text, (close_x, close_y))
            
        except Exception as e:
            print(f"绘制界面出错: {e}")
        
    def run(self):
        """运行关于窗口"""
        clock = pygame.time.Clock()
        running = True
        
        print(f"关于窗口启动，大小: {self.width}x{self.height}")
        
        while running:
            try:
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        running = False
                    
                    elif event.type == pygame.MOUSEBUTTONDOWN:
                        if event.button == 1:
                            if self.close_button_rect.collidepoint(event.pos):
                                running = False
                
                self.draw()
                pygame.display.flip()
                clock.tick(60)
                
            except Exception as e:
                print(f"事件处理出错: {e}")
                running = False
        
        try:
            pygame.quit()
        except:
            pass

def main():
    """主函数 - 接收命令行参数"""
    try:
        # 获取命令行参数中的窗口大小
        if len(sys.argv) >= 3:
            try:
                width = int(sys.argv[1])
                height = int(sys.argv[2])
                print(f"接收到窗口大小参数: {width}x{height}")
            except ValueError:
                print("窗口大小参数无效，使用默认值")
                width, height = 400, 500
        else:
            print("未接收到窗口大小参数，使用默认值")
            width, height = 400, 500
            
        app = AboutWindow(width, height)
        app.run()
    except Exception as e:
        print(f"关于页面运行出错: {e}")
        import traceback
        traceback.print_exc()
        
        # 保持窗口打开，让用户看到错误信息
        input("按回车键退出...")
    finally:
        try:
            pygame.quit()
        except:
            pass
        sys.exit()

if __name__ == "__main__":
    main()