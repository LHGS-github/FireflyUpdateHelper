import mailbox
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '库'))

# 现在可以正常导入pygame
import pygame
import subprocess
import tkinter as tk
from tkinter import filedialog, simpledialog, messagebox
import traceback
import platform

# 会员：@Leonard Liu 008
# 添加当前目录到路径，确保资源文件能被找到
if __file__:
    os.chdir(os.path.dirname(os.path.abspath(__file__)))

# 检测操作系统
# @雨行万里 改了下逻辑
SYSTEM = platform.system()

# Windows 特定导入
if SYSTEM == "Windows":
    try:
        import ctypes
    except ImportError:
        ctypes = None

def show_message(title, message, msg_type="info"):
    """显示消息框的辅助函数"""
    try:
        root = tk.Tk()
        root.withdraw()
        if msg_type == "error":
            messagebox.showerror(title, message)
        elif msg_type == "warning":
            messagebox.showwarning(title, message)
        else:
            messagebox.showinfo(title, message)
        root.destroy()
    except:
        show_message("提示", f"{title}: {message}")

class ResizableWindow:
    def __init__(self):
        pygame.init()
        # 设置窗口标题
        pygame.display.set_caption("小N看图")

        # 获取屏幕信息
        info = pygame.display.Info()
        screen_width = info.current_w
        screen_height = info.current_h

        # 设置窗口大小（屏幕的80%，但不超过1200x800）
        self.width = min(1200, int(screen_width * 0.8))
        self.height = min(800, int(screen_height * 0.8))

        # 标题栏高度（仅Windows使用自定义标题栏）
        self.title_bar_height = 30 if SYSTEM=="Windows" else 0

        # 创建窗口（根据平台选择模式）
        if SYSTEM=="Windows":
            # Windows使用无边框窗口
            self.screen = pygame.display.set_mode(
                (self.width, self.height),
                pygame.NOFRAME | pygame.RESIZABLE
            )
        else:
            # Linux和macOS使用标准窗口
            self.screen = pygame.display.set_mode(
                (self.width, self.height),
                pygame.RESIZABLE
            )

        # 窗口位置
        self.window_x = (screen_width - self.width) // 2
        self.window_y = (screen_height - self.height) // 2

        # Windows下移动窗口到中心
        if SYSTEM=="Windows" and ctypes:
            self.move_window(self.window_x, self.window_y)

        # 初始化字体
        self.init_fonts()

        # 加载资源
        self.load_resources()

        # 初始化UI元素
        self.init_ui_elements()

        # 初始化状态
        self.init_states()

    def init_fonts(self):
        """初始化字体"""
        self.font_path = None

        # 根据平台选择字体
        if SYSTEM=="Windows":
            font_names = ['simsun', 'microsoftyahei', 'simhei', 'arial']
        elif SYSTEM=="Darwin":
            font_names = ['pingfang', 'songti', 'heiti', 'helvetica']
        else:  # Linux
            font_names = ['wenquanyi', 'wqy-microhei', 'wqy-zenhei',
                         'noto sans cjk sc', 'dejavu sans', 'liberation sans']

        # 尝试找到可用的字体
        for font_name in font_names:
            font_path = pygame.font.match_font(font_name)
            if font_path:
                self.font_path = font_path
                break

        # 如果没找到，使用默认字体
        if not self.font_path:
            self.font_path = pygame.font.get_default_font()
            show_message("提示", "使用默认字体")

        # 创建字体对象
        try:
            self.title_font = pygame.font.Font(self.font_path, 16)
            self.button_font = pygame.font.Font(self.font_path, 14)
            self.prompt_font = pygame.font.Font(self.font_path, 24)
        except:
            # 使用系统默认字体
            self.title_font = pygame.font.Font(None, 16)
            self.button_font = pygame.font.Font(None, 14)
            self.prompt_font = pygame.font.Font(None, 24)

    def load_resources(self):
        """加载资源文件"""
        # 尝试加载图标
        try:
            icon_path = os.path.join("images", "图标.png")
            if os.path.exists(icon_path):
                icon = pygame.image.load(icon_path)
                pygame.display.set_icon(icon)
            else:
                show_message("提示", f"图标文件不存在: {icon_path}")
        except Exception as e:
            show_message("错误", f"无法加载图标: {e}")

        # 尝试加载背景图片
        try:
            bg_path = os.path.join("images", "背景.png")
            if os.path.exists(bg_path):
                self.background_image = pygame.image.load(bg_path)
                # 缩放背景图片
                bg_height = self.height - self.title_bar_height
                self.background_image = pygame.transform.scale(
                    self.background_image,
                    (self.width, bg_height)
                )
                self.background_rect = self.background_image.get_rect(
                    topleft=(0, self.title_bar_height)
                )
            else:
                show_message("提示", f"背景图片不存在: {bg_path}")
                self.background_image = None
                self.background_rect = None
        except Exception as e:
            show_message("错误", f"无法加载背景图片: {e}")
            self.background_image = None
            self.background_rect = None

    def init_ui_elements(self):
        """初始化UI元素"""
        # 颜色设置
        self.bg_color = (240, 240, 240)
        self.title_bar_color = (50, 50, 50)
        self.title_text_color = (255, 255, 255)

        # 按钮通用设置
        button_y = (self.title_bar_height - 24) // 2 if SYSTEM=="Windows" else 5

        # 文件按钮
        self.custom_button_width = 100
        self.custom_button_height = 24
        self.custom_button_x = 120 if SYSTEM=="Windows" else 10
        self.custom_button_y = button_y
        self.custom_button_rect = pygame.Rect(
            self.custom_button_x, self.custom_button_y,
            self.custom_button_width, self.custom_button_height
        )
        self.custom_button_color = (100, 149, 237)
        self.custom_button_hover_color = (135, 206, 250)
        self.custom_button_text = "文件"

        # 编辑按钮
        self.edit_button_width = 100
        self.edit_button_height = 24
        self.edit_button_x = self.custom_button_x + self.custom_button_width + 10
        self.edit_button_y = button_y
        self.edit_button_rect = pygame.Rect(
            self.edit_button_x, self.edit_button_y,
            self.edit_button_width, self.edit_button_height
        )
        self.edit_button_color = (100, 149, 237)
        self.edit_button_hover_color = (135, 206, 250)
        self.edit_button_text = "编辑"

                # 关于按钮
        self.about_button_width = 60
        self.about_button_height = 24
        self.about_button_x = self.width - 140 if SYSTEM=="Windows" else self.edit_button_x + self.edit_button_width + 10
        self.about_button_y = button_y
        self.about_button_rect = pygame.Rect(
            self.about_button_x, self.about_button_y,
            self.about_button_width, self.about_button_height
        )
        self.about_button_color = (100, 149, 237)
        self.about_button_hover_color = (135, 206, 250)
        self.about_button_text = "关于"

        # 文件下拉菜单
        dropdown_y = self.title_bar_height if SYSTEM=="Windows" else 35
        self.dropdown_items = ["打开文件", "保存图片", "另存为"]
        self.dropdown_width = self.custom_button_width
        self.dropdown_height = len(self.dropdown_items) * 30
        self.dropdown_rect = pygame.Rect(
            self.custom_button_x, dropdown_y,
            self.dropdown_width, self.dropdown_height
        )
        self.dropdown_visible = False
        self.dropdown_item_hover = -1
        self.dropdown_colors = {
            'bg': (240, 240, 240),
            'hover': (135, 206, 250),
            'text': (0, 0, 0),
            'border': (100, 149, 237)
        }

        # 编辑下拉菜单
        self.edit_dropdown_items = ["格式转换", "裁剪图片", "旋转图片"]
        self.edit_dropdown_width = self.edit_button_width
        self.edit_dropdown_height = len(self.edit_dropdown_items) * 30
        self.edit_dropdown_rect = pygame.Rect(
            self.edit_button_x, dropdown_y,
            self.edit_dropdown_width, self.edit_dropdown_height
        )
        self.edit_dropdown_visible = False
        self.edit_dropdown_item_hover = -1
        self.edit_dropdown_colors = self.dropdown_colors.copy()

        # Windows控制按钮
        if SYSTEM=="Windows":
            self.control_button_width = 30
            self.control_button_height = 30
            self.min_button_rect = pygame.Rect(
                self.width - 70, 0,
                self.control_button_width, self.control_button_height
            )
            self.close_button_rect = pygame.Rect(
                self.width - 40, 0,
                self.control_button_width, self.control_button_height
            )
        else:
            # 其他平台不需要自定义控制按钮
            self.min_button_rect = pygame.Rect(0, 0, 0, 0)
            self.close_button_rect = pygame.Rect(0, 0, 0, 0)

    def init_states(self):
        """初始化状态变量"""
        # 图片相关
        self.user_image = None
        self.user_image_rect = None
        self.original_image_size = None
        self.image_loaded = False
        self.image_format = None
        self.scale_factor = 1.0

        # 拖动相关
        self.dragging = False
        self.drag_start_x = 0
        self.drag_start_y = 0
        self.dragging_image = False
        self.drag_image_start_x = 0
        self.drag_image_start_y = 0

        # 窗口状态
        self.original_size = (self.width, self.height)
        self.original_position = (self.window_x, self.window_y)
        self.title_bar_visible = SYSTEM=="Windows"

        # 裁剪相关
        self.cropping = False

    def move_window(self, x, y):
        """移动窗口（仅Windows）"""
        if SYSTEM=="Windows" and ctypes:
            try:
                hwnd = pygame.display.get_wm_info()['window']
                ctypes.windll.user32.SetWindowPos(hwnd, 0, x, y, 0, 0, 0x0001)
            except:
                pass

    def minimize_window(self):
        """最小化窗口"""
        if SYSTEM=="Windows" and ctypes:
            try:
                hwnd = pygame.display.get_wm_info()['window']
                ctypes.windll.user32.ShowWindow(hwnd, 6)
            except:
                pygame.display.iconify()
        else:
            pygame.display.iconify()

    def draw_title_bar(self):
        """绘制标题栏（仅Windows）"""
        if not SYSTEM=="Windows" or not self.title_bar_visible:
            return

        # 绘制标题栏背景
        title_bar_rect = pygame.Rect(0, 0, self.width, self.title_bar_height)
        pygame.draw.rect(self.screen, self.title_bar_color, title_bar_rect)

        # 绘制图标
        try:
            icon_path = os.path.join("images", "图标.png")
            if os.path.exists(icon_path):
                icon = pygame.image.load(icon_path)
                icon = pygame.transform.scale(icon, (20, 20))
                self.screen.blit(icon, (10, (self.title_bar_height - 20) // 2))
        except:
            pass

        # 绘制标题文本
        try:
            title_text = self.title_font.render("小N看图1.3", True, self.title_text_color)
            self.screen.blit(title_text, (40, (self.title_bar_height - title_text.get_height()) // 2))
        except:
            pass

        # 绘制最小化按钮
        pygame.draw.rect(self.screen, (200, 200, 200), self.min_button_rect)
        pygame.draw.line(self.screen, (0, 0, 0),
                        (self.min_button_rect.x + 5, self.min_button_rect.y + 15),
                        (self.min_button_rect.x + 25, self.min_button_rect.y + 15), 2)

        # 绘制关闭按钮
        pygame.draw.rect(self.screen, (255, 99, 71), self.close_button_rect)
        pygame.draw.line(self.screen, (255, 255, 255),
                        (self.close_button_rect.x + 8, self.close_button_rect.y + 8),
                        (self.close_button_rect.x + 22, self.close_button_rect.y + 22), 2)
        pygame.draw.line(self.screen, (255, 255, 255),
                        (self.close_button_rect.x + 22, self.close_button_rect.y + 8),
                        (self.close_button_rect.x + 8, self.close_button_rect.y + 22), 2)

    def draw_buttons(self):
        """绘制按钮和下拉菜单"""
        mouse_pos = pygame.mouse.get_pos()

        # 绘制文件按钮
        is_hover = self.custom_button_rect.collidepoint(mouse_pos)
        color = self.custom_button_hover_color if is_hover else self.custom_button_color
        pygame.draw.rect(self.screen, color, self.custom_button_rect)
        pygame.draw.rect(self.screen, (0, 0, 0), self.custom_button_rect, 1)

        try:
            text = self.button_font.render(self.custom_button_text, True, (255, 255, 255))
            text_rect = text.get_rect(center=self.custom_button_rect.center)
            self.screen.blit(text, text_rect)
        except:
            pass

        # 绘制编辑按钮
        is_hover = self.edit_button_rect.collidepoint(mouse_pos)
        color = self.edit_button_hover_color if is_hover else self.edit_button_color
        pygame.draw.rect(self.screen, color, self.edit_button_rect)
        pygame.draw.rect(self.screen, (0, 0, 0), self.edit_button_rect, 1)

        try:
            text = self.button_font.render(self.edit_button_text, True, (255, 255, 255))
            text_rect = text.get_rect(center=self.edit_button_rect.center)
            self.screen.blit(text, text_rect)
        except:
            pass

                # 绘制关于按钮
        is_hover = self.about_button_rect.collidepoint(mouse_pos)
        color = self.about_button_hover_color if is_hover else self.about_button_color
        pygame.draw.rect(self.screen, color, self.about_button_rect)
        pygame.draw.rect(self.screen, (0, 0, 0), self.about_button_rect, 1)

        try:
            text = self.button_font.render(self.about_button_text, True, (255, 255, 255))
            text_rect = text.get_rect(center=self.about_button_rect.center)
            self.screen.blit(text, text_rect)
        except:
            pass

        # 绘制下拉菜单
        self.draw_dropdown_menu(mouse_pos)

    def draw_dropdown_menu(self, mouse_pos):
        """绘制下拉菜单"""
        # 文件下拉菜单
        if self.dropdown_visible:
            pygame.draw.rect(self.screen, self.dropdown_colors['bg'], self.dropdown_rect)
            pygame.draw.rect(self.screen, self.dropdown_colors['border'], self.dropdown_rect, 1)

            for i, item in enumerate(self.dropdown_items):
                item_rect = pygame.Rect(
                    self.dropdown_rect.x,
                    self.dropdown_rect.y + i * 30,
                    self.dropdown_rect.width, 30
                )

                # 检查鼠标悬停
                if item_rect.collidepoint(mouse_pos):
                    pygame.draw.rect(self.screen, self.dropdown_colors['hover'], item_rect)
                else:
                    pygame.draw.rect(self.screen, self.dropdown_colors['bg'], item_rect)

                # 绘制分割线
                if i < len(self.dropdown_items) - 1:
                    pygame.draw.line(self.screen, self.dropdown_colors['border'],
                                   (item_rect.x, item_rect.bottom),
                                   (item_rect.right, item_rect.bottom), 1)

                # 绘制文本
                try:
                    text = self.button_font.render(item, True, self.dropdown_colors['text'])
                    text_rect = text.get_rect(center=item_rect.center)
                    self.screen.blit(text, text_rect)
                except:
                    pass

        # 编辑下拉菜单
        if self.edit_dropdown_visible:
            pygame.draw.rect(self.screen, self.edit_dropdown_colors['bg'], self.edit_dropdown_rect)
            pygame.draw.rect(self.screen, self.edit_dropdown_colors['border'], self.edit_dropdown_rect, 1)

            for i, item in enumerate(self.edit_dropdown_items):
                item_rect = pygame.Rect(
                    self.edit_dropdown_rect.x,
                    self.edit_dropdown_rect.y + i * 30,
                    self.edit_dropdown_rect.width, 30
                )

                # 检查鼠标悬停
                if item_rect.collidepoint(mouse_pos):
                    pygame.draw.rect(self.screen, self.edit_dropdown_colors['hover'], item_rect)
                else:
                    pygame.draw.rect(self.screen, self.edit_dropdown_colors['bg'], item_rect)

                # 绘制分割线
                if i < len(self.edit_dropdown_items) - 1:
                    pygame.draw.line(self.screen, self.edit_dropdown_colors['border'],
                                   (item_rect.x, item_rect.bottom),
                                   (item_rect.right, item_rect.bottom), 1)

                # 绘制文本
                try:
                    text = self.button_font.render(item, True, self.edit_dropdown_colors['text'])
                    text_rect = text.get_rect(center=item_rect.center)
                    self.screen.blit(text, text_rect)
                except:
                    pass

    def draw_transparent_box(self):
        """绘制透明框"""
        margin = 20
        box_width = self.width - margin * 2
        box_height = self.height - self.title_bar_height - margin * 2
        box_x = margin
        box_y = self.title_bar_height + margin if SYSTEM=="Windows" else margin

        # 创建透明表面
        surf = pygame.Surface((box_width, box_height), pygame.SRCALPHA)
        surf.fill((150, 150, 150, 100))
        self.screen.blit(surf, (box_x, box_y))

    def draw_beautiful_prompt(self):
        """绘制提示文字"""
        prompt_text = "请选择图片"

        try:
            font = pygame.font.Font(self.font_path, 36)
        except:
            font = pygame.font.Font(None, 36)

        # 计算中心位置
        center_x = self.width // 2
        center_y = self.height // 2

        # 绘制阴影效果
        for offset in range(3, 0, -1):
            shadow_color = (100, 100, 100, 50)
            shadow_text = font.render(prompt_text, True, (100, 100, 100))
            shadow_text.set_alpha(50 * offset)
            shadow_rect = shadow_text.get_rect(center=(center_x + offset, center_y + offset))
            self.screen.blit(shadow_text, shadow_rect)

        # 绘制主文本
        main_text = font.render(prompt_text, True, (70, 130, 180))
        main_rect = main_text.get_rect(center=(center_x, center_y))
        self.screen.blit(main_text, main_rect)

    def open_file_dialog(self):
        """打开文件选择对话框"""
        try:
            root = tk.Tk()
            root.withdraw()

            # 根据平台设置文件类型
            # 定义通用的图片文件扩展名列表
            image_extensions = [
                "*.png", "*.jpg", "*.jpeg", "*.bmp", "*.gif", "*.tga", "*.tiff", "*.tif",
                "*.webp", "*.pcx", "*.pbm", "*.pgm", "*.ppm", "*.pnm", "*.lbm", "*.pcd",
                "*.xpm", "*.xwd", "*.svg", "*.svgz", "*.ico", "*.cur", "*.icns", "*.exr",
                "*.hdr", "*.psd", "*.raw", "*.nef", "*.cr2", "*.orf", "*.sr2", "*.raf",
                "*.arw", "*.dng", "*.pef", "*.srw", "*.mrw", "*.kdc", "*.3fr", "*.ari",
                "*.bay", "*.bmq", "*.cap", "*.cine", "*.crw", "*.cs1", "*.dcr", "*.dcs",
                "*.drf", "*.eip", "*.erf", "*.fff", "*.gpr", "*.iiq", "*.j6i", "*.jng",
                "*.jpe", "*.jps", "*.jxr", "*.k25", "*.kcap", "*.mdc", "*.mef", "*.mos",
                "*.mrw", "*.nrw", "*.obm", "*.orf", "*.pef", "*.ptx", "*.pxn", "*.qtk",
                "*.raf", "*.raw", "*.rdc", "*.rw2", "*.rwl", "*.rwz", "*.srf", "*.sr2",
                "*.sti", "*.tga", "*.thm", "*.tif", "*.vrd", "*.wdp", "*.x3f", "*.xpm",
                "*.xwd", "*.yuv", "*.apng", "*.avif", "*.bpg", "*.cals", "*.cd5", "*.ciff",
                "*.cmx", "*.cut", "*.dds", "*.dpx", "*.emf", "*.eps", "*.fpx", "*.fits",
                "*.flif", "*.ftc", "*.ftu", "*.gbr", "*.gd", "*.grib", "*.hgl", "*.icb",
                "*.ief", "*.iff", "*.jfif", "*.jls", "*.jpc", "*.jpf", "*.jpx", "*.j2k",
                "*.j2c", "*.jng", "*.kra", "*.mng", "*.msp", "*.npx", "*.pct", "*.pict",
                "*.pix", "*.pns", "*.psb", "*.pspimage", "*.pvr", "*.qdraw", "*.sct",
                "*.softimage", "*.spi", "*.thumbs", "*.ufo", "*.ufraw", "*.vicar", "*.viff",
                "*.wbm", "*.wmf", "*.ycbcr", "*.ycck", "*.ai", "*.art", "*.blp", "*.bw",
                "*.cgm", "*.clip", "*.cmyk", "*.cpt", "*.dcx", "*.dib", "*.dxf", "*.fbs",
                "*.fst", "*.g3", "*.icm", "*.imt", "*.iwi", "*.jbg", "*.jbig", "*.jbig2",
                "*.jpm", "*.jpt", "*.jpeg-ls", "*.jxl", "*.kpc", "*.miff", "*.mpo",
                "*.mrsid", "*.napraw", "*.niff", "*.nsv", "*.pam", "*.picon", "*.pixar",
                "*.xyl"
            ]

            # 修复文件类型元组格式，每个元组只能有两个元素
            filetypes = [("图片文件", " ".join(image_extensions))]

            file_path = filedialog.askopenfilename(
                title="选择图片文件",
                filetypes=filetypes
            )

            root.destroy()

            if file_path:
                self.load_image(file_path)

        except Exception as e:
            show_message("错误", f"打开文件对话框错误: {e}")
            messagebox.showerror("错误", f"无法打开文件对话框: {e}")

    def load_image(self, file_path):
        """加载图片"""
        try:
            # 检查文件是否存在
            if not os.path.exists(file_path):
                messagebox.showerror("错误", "文件不存在")
                return

            # 获取文件格式
            self.image_format = os.path.splitext(file_path)[1].lower()[1:]

            # 检查格式是否支持
            supported_formats = ['png', 'jpg', 'jpeg', 'bmp', 'gif', 'tga', 'tiff', 'tif', 'webp', 'pcx', 'pbm', 'pgm', 'ppm', 'pnm', 'lbm', 'pcd', 'xpm', 'xwd', 'svg', 'svgz', 'ico', 'cur', 'icns', 'exr', 'hdr', 'psd', 'raw', 'nef', 'cr2', 'orf', 'sr2', 'raf', 'arw', 'dng', 'pef', 'srw', 'mrw', 'kdc', '3fr', 'ari', 'bay', 'bmq', 'cap', 'cine', 'crw', 'cs1', 'dcr', 'dcs', 'drf', 'eip', 'erf', 'fff', 'gpr', 'iiq', 'j6i', 'jng', 'jpe', 'jps', 'jxr', 'k25', 'kcap', 'mdc', 'mef', 'mos', 'mrw', 'nrw', 'obm', 'orf', 'pef', 'ptx', 'pxn', 'qtk', 'raf', 'raw', 'rdc', 'rw2', 'rwl', 'rwz', 'srf', 'sr2', 'sti', 'tga', 'thm', 'tif', 'vrd', 'wdp', 'x3f', 'xpm', 'xwd', 'yuv', 'apng', 'avif', 'bpg', 'cals', 'cd5', 'ciff', 'cmx', 'cut', 'dds', 'dpx', 'emf', 'eps', 'fpx', 'fits', 'flif', 'fpx', 'ftc', 'ftu', 'gbr', 'gd', 'grib', 'hgl', 'icb', 'ief', 'iff', 'jfif', 'jls', 'jpc', 'jpf', 'jpx', 'j2k', 'j2c', 'jng', 'jpc', 'jxr', 'kra', 'mng', 'msp', 'nef', 'npx', 'pbm', 'pct', 'pgm', 'pict', 'pix', 'pnm', 'pns', 'ppm', 'psd', 'psp', 'pxr', 'qfx', 'qif', 'qti', 'qtif', 'ras', 'rgb', 'rgba', 'rle', 'sgi', 'sid', 'sun', 'tga', 'tiff', 'uop', 'vda', 'vst', 'wbmp', 'xbm', 'xpm', 'xwd', 'ycbcr', 'ycck', 'ai', 'art', 'blp', 'bw', 'cgm', 'clip', 'cmyk', 'cpt', 'dcx', 'dib', 'dxf', 'fbs', 'fits', 'fpx', 'fst', 'g3', 'icm', 'ico', 'imt', 'iwi', 'jbg', 'jbig', 'jbig2', 'jpm', 'jps', 'jpt', 'jpeg-ls', 'jxl', 'kpc', 'miff', 'mpo', 'mrsid', 'napraw', 'niff', 'nsv', 'pam', 'pbm', 'pct', 'pcx', 'pgf', 'pgm', 'picon', 'pict', 'pixar', 'pnm', 'ppm', 'psb', 'pspimage', 'pvr', 'qdraw', 'rgb', 'rgba', 'sct', 'sgi', 'softimage', 'spi', 'srf', 'tga', 'thumbs', 'ufo', 'ufraw', 'vicar', 'viff', 'vst', 'wbm', 'webp', 'wmf', 'xpm', 'xwd', 'xyl']
            if self.image_format not in supported_formats:
                messagebox.showerror("错误", f"不支持的图片格式: {self.image_format}")
                return

            # 加载图片
            self.user_image = pygame.image.load(file_path)
            self.original_image_size = self.user_image.get_size()
            self.image_loaded = True

            # 计算居中位置
            window_width = self.width
            window_height = self.height - self.title_bar_height

            img_width, img_height = self.original_image_size

            # 如果图片太大，缩放到窗口大小
            if img_width > window_width or img_height > window_height:
                scale_x = window_width / img_width
                scale_y = window_height / img_height
                scale = min(scale_x, scale_y) * 0.9  # 留10%边距

                new_width = int(img_width * scale)
                new_height = int(img_height * scale)

                self.user_image = pygame.transform.scale(self.user_image, (new_width, new_height))
                img_width, img_height = new_width, new_height

            # 居中显示
            x_pos = (window_width - img_width) // 2
            y_pos = self.title_bar_height + (window_height - img_height) // 2
            self.user_image_rect = self.user_image.get_rect(topleft=(x_pos, y_pos))

            show_message("成功", f"成功加载图片: {file_path}\n图片格式: {self.image_format}\n原始尺寸: {self.original_image_size}")

        except pygame.error as e:
            messagebox.showerror("错误", f"无法加载图片: {e}")
            self.image_loaded = False
        except Exception as e:
            messagebox.showerror("错误", f"加载图片时出错: {e}")
            self.image_loaded = False

    def save_image(self):
        """保存图片"""
        if not self.image_loaded or not self.user_image:
            messagebox.showinfo("提示", "没有加载图片")
            return

        try:
            root = tk.Tk()
            root.withdraw()

            # 默认扩展名
            default_ext = f".{self.image_format}" if self.image_format else ".png"

            file_path = filedialog.asksaveasfilename(
                title="保存图片",
                defaultextension=default_ext,
                filetypes=[
                    ("其他图片文件", "*.*")
                ]
            )

            root.destroy()

            if file_path:
                # 根据扩展名确定格式
                ext = os.path.splitext(file_path)[1].lower()[1:]

                # 保存图片
                if ext in ['jpg', 'jpeg']:
                    # JPEG需要RGB模式
                    temp_surf = pygame.Surface(self.user_image.get_size(), 0, 24)
                    temp_surf.blit(self.user_image, (0, 0))
                    pygame.image.save(temp_surf, file_path)
                else:
                    pygame.image.save(self.user_image, file_path)

                messagebox.showinfo("成功", f"图片已保存到:\n{file_path}")

        except Exception as e:
            messagebox.showerror("错误", f"保存图片失败: {e}")

    def convert_image_format(self):
        """格式转换"""
        if not self.image_loaded or not self.user_image:
            messagebox.showinfo("提示", "没有加载图片")
            return

        try:
            from tkinter import ttk

            root = tk.Tk()
            root.title("格式转换")
            root.withdraw()

            # 创建对话框
            dialog = tk.Toplevel(root)
            dialog.title("格式转换")
            dialog.geometry("300x150")

            # 居中显示
            dialog.update_idletasks()
            x = (dialog.winfo_screenwidth() // 2) - (300 // 2)
            y = (dialog.winfo_screenheight() // 2) - (150 // 2)
            dialog.geometry(f"+{x}+{y}")

            # 格式选择
            formats = ["png", "jpg", "bmp", "gif"]
            current = self.image_format if self.image_format in formats else "png"

            tk.Label(dialog, text=f"当前格式: {current.upper()}").pack(pady=10)
            tk.Label(dialog, text="选择目标格式:").pack()

            format_var = tk.StringVar(value=current)
            format_combo = ttk.Combobox(dialog, textvariable=format_var,
                                       values=formats, state="readonly", width=10)
            format_combo.pack(pady=10)

            # 按钮框架
            btn_frame = tk.Frame(dialog)
            btn_frame.pack(pady=10)

            def on_convert():
                new_format = format_var.get()
                dialog.destroy()
                root.destroy()

                # 选择保存位置
                self.save_as_format(new_format)

            def on_cancel():
                dialog.destroy()
                root.destroy()

            tk.Button(btn_frame, text="转换", command=on_convert, width=10).pack(side=tk.LEFT, padx=5)
            tk.Button(btn_frame, text="取消", command=on_cancel, width=10).pack(side=tk.LEFT, padx=5)

            dialog.protocol("WM_DELETE_WINDOW", on_cancel)
            root.mainloop()

        except Exception as e:
            messagebox.showerror("错误", f"格式转换失败: {e}")

    def save_as_format(self, format):
        """另存为指定格式"""
        try:
            root = tk.Tk()
            root.withdraw()

            file_path = filedialog.asksaveasfilename(
                title=f"另存为{format.upper()}格式",
                defaultextension=f".{format}",
                filetypes=[
                    (f"{format.upper()}文件", f"*.{format}"),
                    ("所有文件", "*.*")
                ]
            )

            root.destroy()

            if file_path:
                # 保存为指定格式
                if format in ['jpg', 'jpeg']:
                    # JPEG需要RGB模式
                    temp_surf = pygame.Surface(self.user_image.get_size(), 0, 24)
                    temp_surf.blit(self.user_image, (0, 0))
                    pygame.image.save(temp_surf, file_path)
                else:
                    pygame.image.save(self.user_image, file_path)

                messagebox.showinfo("成功", f"图片已转换并保存到:\n{file_path}")

        except Exception as e:
            messagebox.showerror("错误", f"保存失败: {e}")

    def crop_image(self):
        """裁剪图片"""
        if not self.image_loaded or not self.user_image:
            messagebox.showinfo("提示", "没有加载图片")
            return

        # 进入裁剪模式
        self.cropping = True
        self.original_image = self.user_image.copy()
        self.original_image_rect = self.user_image_rect.copy()

        img_width, img_height = self.original_image.get_size()

        # 初始裁剪框（图片中央50%大小）
        self.crop_rect = pygame.Rect(
            img_width // 4, img_height // 4,
            img_width // 2, img_height // 2
        )

        self.dragging_edge = None
        self.drag_start_pos = None
        self.crop_rect_modified = False
        self.original_crop_rect = None

        # 创建裁剪按钮
        self.init_crop_button()

        # 裁剪循环
        clock = pygame.time.Clock()

        while self.cropping:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.cropping = False
                    pygame.quit()
                    sys.exit()

                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        self.cropping = False
                    elif event.key == pygame.K_RETURN:
                        self.perform_crop()

                elif event.type == pygame.MOUSEBUTTONDOWN:
                    if event.button == 1:
                        # Windows控制按钮
                        if SYSTEM=="Windows":
                            if self.close_button_rect.collidepoint(event.pos):
                                self.cropping = False
                                return
                            elif self.min_button_rect.collidepoint(event.pos):
                                self.minimize_window()
                                continue
                            elif event.pos[1] <= self.title_bar_height:
                                self.dragging = True
                                self.drag_start_x = event.pos[0]
                                self.drag_start_y = event.pos[1]
                                continue

                        # 裁剪完成按钮
                        if self.crop_button_rect.collidepoint(event.pos):
                            self.perform_crop()
                            continue

                        # 检查裁剪框边缘
                        img_x = event.pos[0] - self.user_image_rect.x
                        img_y = event.pos[1] - self.user_image_rect.y

                        if 0 <= img_x <= img_width and 0 <= img_y <= img_height:
                            edge = self.get_crop_edge(img_x, img_y)
                            if edge:
                                self.dragging_edge = edge
                                self.drag_start_pos = (img_x, img_y)
                                self.original_crop_rect = self.crop_rect.copy()

                elif event.type == pygame.MOUSEMOTION:
                    if SYSTEM=="Windows" and self.dragging:
                        dx = event.pos[0] - self.drag_start_x
                        dy = event.pos[1] - self.drag_start_y
                        new_x = self.window_x + dx
                        new_y = self.window_y + dy
                        self.move_window(new_x, new_y)
                        self.window_x, self.window_y = new_x, new_y
                        continue

                    if self.dragging_edge and self.drag_start_pos:
                        img_x = event.pos[0] - self.user_image_rect.x
                        img_y = event.pos[1] - self.user_image_rect.y
                        img_x = max(0, min(img_x, img_width))
                        img_y = max(0, min(img_y, img_height))
                        self.adjust_crop_rect(img_x, img_y, img_width, img_height)
                        self.crop_rect_modified = True

                elif event.type == pygame.MOUSEBUTTONUP:
                    self.dragging = False
                    self.dragging_edge = None
                    self.drag_start_pos = None

            # 绘制裁剪界面
            self.draw_crop_interface()
            pygame.display.flip()
            clock.tick(60)

    def init_crop_button(self):
        """初始化裁剪按钮"""
        self.crop_button_width = 120
        self.crop_button_height = 30
        self.crop_button_x = self.width - self.crop_button_width - 20
        self.crop_button_y = self.height - self.crop_button_height - 20
        self.crop_button_rect = pygame.Rect(
            self.crop_button_x, self.crop_button_y,
            self.crop_button_width, self.crop_button_height
        )

    def draw_crop_interface(self):
        """绘制裁剪界面"""
        # 背景
        self.screen.fill(self.bg_color)
        if self.background_image:
            self.screen.blit(self.background_image, self.background_rect)

        # 原图
        self.screen.blit(self.original_image, self.original_image_rect)

        # 裁剪框
        if self.crop_rect:
            # 确保裁剪框在图片范围内
            img_width, img_height = self.original_image.get_size()
            self.crop_rect.left = max(0, min(self.crop_rect.left, img_width - 1))
            self.crop_rect.top = max(0, min(self.crop_rect.top, img_height - 1))
            self.crop_rect.right = min(img_width, self.crop_rect.right)
            self.crop_rect.bottom = min(img_height, self.crop_rect.bottom)

            # 转换为屏幕坐标
            screen_rect = pygame.Rect(
                self.user_image_rect.x + self.crop_rect.x,
                self.user_image_rect.y + self.crop_rect.y,
                self.crop_rect.width,
                self.crop_rect.height
            )

            # 绘制半透明遮罩
            overlay = pygame.Surface((self.original_image_rect.width, self.original_image_rect.height),
                                    pygame.SRCALPHA)
            overlay.fill((0, 0, 0, 128))
            # 清除裁剪区域
            pygame.draw.rect(overlay, (0, 0, 0, 0),
                           (self.crop_rect.x, self.crop_rect.y,
                            self.crop_rect.width, self.crop_rect.height))
            self.screen.blit(overlay, self.original_image_rect)

            # 绘制裁剪框边框
            pygame.draw.rect(self.screen, (255, 0, 0), screen_rect, 2)

            # 绘制控制点
            self.draw_crop_handles(screen_rect)

        # 绘制裁剪按钮
        mouse_pos = pygame.mouse.get_pos()
        is_hover = self.crop_button_rect.collidepoint(mouse_pos)
        color = (135, 206, 250) if is_hover else (100, 149, 237)

        pygame.draw.rect(self.screen, color, self.crop_button_rect)
        pygame.draw.rect(self.screen, (0, 0, 0), self.crop_button_rect, 1)

        try:
            text = self.button_font.render("完成裁剪", True, (255, 255, 255))
            text_rect = text.get_rect(center=self.crop_button_rect.center)
            self.screen.blit(text, text_rect)
        except:
            pass

        # 绘制提示文字
        try:
            hint_text = self.button_font.render("拖动边框调整裁剪区域，按ESC取消", True, (50, 50, 50))
            self.screen.blit(hint_text, (10, self.height - 30))
        except:
            pass

        # Windows标题栏
        if SYSTEM=="Windows":
            self.draw_title_bar()

    def draw_crop_handles(self, rect):
        """绘制裁剪框控制点"""
        handle_size = 8
        handle_color = (255, 255, 0)

        # 四边中点
        handles = [
            (rect.left, rect.centery),  # 左
            (rect.right, rect.centery),  # 右
            (rect.centerx, rect.top),  # 上
            (rect.centerx, rect.bottom),  # 下
            (rect.left, rect.top),  # 左上
            (rect.right, rect.top),  # 右上
            (rect.left, rect.bottom),  # 左下
            (rect.right, rect.bottom),  # 右下
        ]

        for x, y in handles:
            pygame.draw.rect(self.screen, handle_color,
                           (x - handle_size//2, y - handle_size//2,
                            handle_size, handle_size))

    def get_crop_edge(self, x, y):
        """获取点击的裁剪框边缘"""
        threshold = 10
        rect = self.crop_rect

        # 检查角点
        corners = [
            ('topleft', rect.left, rect.top),
            ('topright', rect.right, rect.top),
            ('bottomleft', rect.left, rect.bottom),
            ('bottomright', rect.right, rect.bottom),
        ]

        for name, cx, cy in corners:
            if abs(x - cx) < threshold and abs(y - cy) < threshold:
                return name

        # 检查边
        if abs(x - rect.left) < threshold and rect.top <= y <= rect.bottom:
            return 'left'
        elif abs(x - rect.right) < threshold and rect.top <= y <= rect.bottom:
            return 'right'
        elif abs(y - rect.top) < threshold and rect.left <= x <= rect.right:
            return 'top'
        elif abs(y - rect.bottom) < threshold and rect.left <= x <= rect.right:
            return 'bottom'

        return None

    def adjust_crop_rect(self, x, y, img_width, img_height):
        """调整裁剪框"""
        if not self.original_crop_rect:
            return

        dx = x - self.drag_start_pos[0]
        dy = y - self.drag_start_pos[1]

        rect = self.original_crop_rect.copy()

        # 根据拖动的边调整
        if self.dragging_edge == 'left':
            new_left = max(0, min(rect.right - 10, rect.left + dx))
            rect.width = rect.right - new_left
            rect.left = new_left
        elif self.dragging_edge == 'right':
            rect.right = max(rect.left + 10, min(img_width, rect.right + dx))
            rect.width = rect.right - rect.left
        elif self.dragging_edge == 'top':
            new_top = max(0, min(rect.bottom - 10, rect.top + dy))
            rect.height = rect.bottom - new_top
            rect.top = new_top
        elif self.dragging_edge == 'bottom':
            rect.bottom = max(rect.top + 10, min(img_height, rect.bottom + dy))
            rect.height = rect.bottom - rect.top
        elif self.dragging_edge == 'topleft':
            new_left = max(0, min(rect.right - 10, rect.left + dx))
            new_top = max(0, min(rect.bottom - 10, rect.top + dy))
            rect.width = rect.right - new_left
            rect.height = rect.bottom - new_top
            rect.left = new_left
            rect.top = new_top
        elif self.dragging_edge == 'topright':
            rect.right = max(rect.left + 10, min(img_width, rect.right + dx))
            new_top = max(0, min(rect.bottom - 10, rect.top + dy))
            rect.width = rect.right - rect.left
            rect.height = rect.bottom - new_top
            rect.top = new_top
        elif self.dragging_edge == 'bottomleft':
            new_left = max(0, min(rect.right - 10, rect.left + dx))
            rect.bottom = max(rect.top + 10, min(img_height, rect.bottom + dy))
            rect.width = rect.right - new_left
            rect.height = rect.bottom - rect.top
            rect.left = new_left
        elif self.dragging_edge == 'bottomright':
            rect.right = max(rect.left + 10, min(img_width, rect.right + dx))
            rect.bottom = max(rect.top + 10, min(img_height, rect.bottom + dy))
            rect.width = rect.right - rect.left
            rect.height = rect.bottom - rect.top

        self.crop_rect = rect

    def perform_crop(self):
        """执行裁剪"""
        if not self.crop_rect_modified:
            result = messagebox.askyesno("确认", "使用当前裁剪框进行裁剪？")
            if not result:
                return

        try:
            # 裁剪图片
            cropped = self.original_image.subsurface(self.crop_rect).copy()
            self.user_image = cropped

            # 更新显示
            cropped_width, cropped_height = cropped.get_size()
            window_width = self.width
            window_height = self.height - self.title_bar_height

            # 居中显示
            x_pos = (window_width - cropped_width) // 2
            y_pos = self.title_bar_height + (window_height - cropped_height) // 2
            self.user_image_rect = self.user_image.get_rect(topleft=(x_pos, y_pos))

            self.original_image_size = self.user_image.get_size()

            messagebox.showinfo("成功", "图片裁剪完成")
            self.cropping = False

        except Exception as e:
            messagebox.showerror("错误", f"裁剪失败: {e}")
    def rotate_image(self):
        """旋转图片"""
        if not self.image_loaded or not self.user_image:
            messagebox.showinfo("提示", "没有加载图片")
            return

        try:
            # 逆时针旋转90度
            self.user_image = pygame.transform.rotate(self.user_image, 90)

            # 更新尺寸和位置
            new_width, new_height = self.user_image.get_size()
            window_width = self.width
            window_height = self.height - self.title_bar_height

            # 如果旋转后太大，缩放
            if new_width > window_width or new_height > window_height:
                scale_x = window_width / new_width
                scale_y = window_height / new_height
                scale = min(scale_x, scale_y) * 0.9

                new_width = int(new_width * scale)
                new_height = int(new_height * scale)
                self.user_image = pygame.transform.scale(self.user_image, (new_width, new_height))

            # 居中显示
            x_pos = (window_width - new_width) // 2
            y_pos = self.title_bar_height + (window_height - new_height) // 2
            self.user_image_rect = self.user_image.get_rect(topleft=(x_pos, y_pos))

            messagebox.showinfo("成功", "图片已旋转90度")

        except Exception as e:
            messagebox.showerror("错误", f"旋转失败: {e}")

    def handle_dropdown_click(self, pos):
        """处理下拉菜单点击"""
        # 文件菜单
        if self.dropdown_visible:
            for i, item in enumerate(self.dropdown_items):
                item_rect = pygame.Rect(
                    self.dropdown_rect.x,
                    self.dropdown_rect.y + i * 30,
                    self.dropdown_rect.width, 30
                )

                if item_rect.collidepoint(pos):
                    if item == "打开文件":
                        self.open_file_dialog()
                    elif item == "保存图片":
                        self.save_image()
                    elif item == "另存为":
                        #self.convert_image_format()
                        show_message("提示", "另存为功能暂未修复")

                    self.dropdown_visible = False
                    break

        # 编辑菜单
        if self.edit_dropdown_visible:
            for i, item in enumerate(self.edit_dropdown_items):
                item_rect = pygame.Rect(
                    self.edit_dropdown_rect.x,
                    self.edit_dropdown_rect.y + i * 30,
                    self.edit_dropdown_rect.width, 30
                )

                if item_rect.collidepoint(pos):
                    if item == "格式转换":
                        #self.convert_image_format()
                        show_message("提示", "格式转换功能暂未修复")
                    elif item == "裁剪图片":
                        self.crop_image()
                    elif item == "旋转图片":
                        self.rotate_image()

                    self.edit_dropdown_visible = False
                    break
    
    def show_about(self):
        """显示关于页面但不关闭主程序"""
        try:
            # 获取当前窗口大小
            current_width = self.width
            current_height = self.height
            
            # 启动关于程序，传递窗口大小参数，但不等待
            about_path = os.path.join(os.path.dirname(__file__), "关于.py")
            if os.path.exists(about_path):
                # 使用subprocess.Popen启动独立进程
                subprocess.Popen([sys.executable, about_path, str(current_width), str(current_height)])
            else:
                show_message("提示", "关于页面文件不存在")
        except Exception as e:
            show_message("错误", f"无法打开关于页面: {e}")

    def run(self):
        """主循环"""
        clock = pygame.time.Clock()
        running = True

        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False

                elif event.type == pygame.VIDEORESIZE:
                    self.width, self.height = event.size

                    # 更新窗口
                    if SYSTEM=="Windows":
                        self.screen = pygame.display.set_mode(
                            (self.width, self.height),
                            pygame.NOFRAME | pygame.RESIZABLE
                        )
                        self.min_button_rect.x = self.width - 70
                        self.close_button_rect.x = self.width - 40
                    else:
                        self.screen = pygame.display.set_mode(
                            (self.width, self.height),
                            pygame.RESIZABLE
                        )

                    # 更新背景图片
                    if self.background_image:
                        try:
                            bg_path = os.path.join("images", "背景.png")
                            if os.path.exists(bg_path):
                                original_bg = pygame.image.load(bg_path)
                                bg_height = self.height - self.title_bar_height
                                self.background_image = pygame.transform.scale(
                                    original_bg, (self.width, bg_height)
                                )
                                self.background_rect = self.background_image.get_rect(
                                    topleft=(0, self.title_bar_height)
                                )
                        except:
                            pass

                elif event.type == pygame.MOUSEBUTTONDOWN:
                    if event.button == 1:
                        # 处理下拉菜单点击
                        self.handle_dropdown_click(event.pos)

                        # Windows控制按钮
                        if SYSTEM=="Windows":
                            if self.close_button_rect.collidepoint(event.pos):
                                running = False
                            elif self.min_button_rect.collidepoint(event.pos):
                                self.minimize_window()
                            elif event.pos[1] <= self.title_bar_height:
                                self.dragging = True
                                self.drag_start_x = event.pos[0]
                                self.drag_start_y = event.pos[1]

                        # 菜单按钮
                        if self.custom_button_rect.collidepoint(event.pos):
                            self.dropdown_visible = not self.dropdown_visible
                            self.edit_dropdown_visible = False
                        elif self.edit_button_rect.collidepoint(event.pos):
                            self.edit_dropdown_visible = not self.edit_dropdown_visible
                            self.dropdown_visible = False
                        elif self.about_button_rect.collidepoint(event.pos):
                            self.show_about()
                            self.dropdown_visible = False
                            self.edit_dropdown_visible = False
                        else:
                            # 点击其他地方关闭菜单
                            if not self.dropdown_rect.collidepoint(event.pos):
                                self.dropdown_visible = False
                            if not self.edit_dropdown_rect.collidepoint(event.pos):
                                self.edit_dropdown_visible = False

                elif event.type == pygame.MOUSEMOTION:
                    if SYSTEM=="Windows" and self.dragging:
                        dx = event.pos[0] - self.drag_start_x
                        dy = event.pos[1] - self.drag_start_y
                        new_x = self.window_x + dx
                        new_y = self.window_y + dy
                        self.move_window(new_x, new_y)
                        self.window_x, self.window_y = new_x, new_y

                elif event.type == pygame.MOUSEBUTTONUP:
                    if event.button == 1:
                        self.dragging = False

                elif event.type == pygame.KEYDOWN:
                    # 快捷键
                    if event.key == pygame.K_o and pygame.key.get_mods() & pygame.KMOD_CTRL:
                        self.open_file_dialog()
                    elif event.key == pygame.K_s and pygame.key.get_mods() & pygame.KMOD_CTRL:
                        self.save_image()

            # 绘制界面
            self.screen.fill(self.bg_color)

            # 背景图片
            if self.background_image:
                self.screen.blit(self.background_image, self.background_rect)

            # 透明框
            self.draw_transparent_box()

            # 用户图片或提示
            if self.user_image and self.user_image_rect:
                self.screen.blit(self.user_image, self.user_image_rect)
            else:
                self.draw_beautiful_prompt()

            # Windows标题栏
            if SYSTEM=="Windows":
                self.draw_title_bar()

            # 按钮和菜单
            self.draw_buttons()

            pygame.display.flip()
            clock.tick(60)

        pygame.quit()
        sys.exit()


def main():
    """主函数"""
    try:
        app = ResizableWindow()
        app.run()
    except Exception as e:
        show_message("错误", f"程序运行出错:\n{e}\n\n{traceback.format_exc()}", "error")
    finally:
        pygame.quit()
        sys.exit()


if __name__ == "__main__":
    main()
